package MijnQien.declaratie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeclaratieApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeclaratieApplication.class, args);
	}

}
